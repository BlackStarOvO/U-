﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using USBMonitor;

namespace WFTest
{
    public partial class _form : Form
    {
        public _form()
        {
            InitializeComponent();
        }
        //CUSBMonitor usbMonitor = new CUSBMonitor();

        protected override void WndProc(ref Message m)
        {
            //usbMonitor.FillData(this, m, _listBox);
            base.WndProc(ref m);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // 获取驱动信息
            var drivers = DriveInfo.GetDrives();
            // 获取移动设备
            foreach (var driver in drivers)
            {
                if (driver.DriveType == DriveType.Removable)
                {
                    MessageBox.Show(driver.Name);
                }
            }
        }

        private void _listBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
