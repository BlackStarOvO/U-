﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using USBMonitor;

namespace UsbViewer
{
    /// <summary>
    /// LoginWindow.xaml 的交互逻辑
    /// </summary>
    public partial class LoginWindow : Window
    {
        public Action LoginSuccessCallback;
        public LoginWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 设置文本显示内容
        /// </summary>
        /// <param name="msg"></param>
        public void SetLabelMsg(string msg)
        {
            this.Label_Msg.Content = msg;
        }

        /// <summary>
        /// 确定按钮, 获取输入的内容
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_OK_Click(object sender, RoutedEventArgs e)
        {
            var username = this.username.Text.Trim();
            var password = this.password.Password.Trim();
            if (string.IsNullOrEmpty(username))
            {
                SetLabelMsg("用户名不为空");
                return;
            }
            if (string.IsNullOrEmpty(password))
            {
                SetLabelMsg("密码不为空");
                return;
            }
            // 登录
            int valid = UsbMonitor.NewInstance().Login(username, password);
            switch (valid)
            {
                case UsbConst.VALID_SUCCESS:            // 验证成功,
                    Dispatcher.BeginInvoke(
                        DispatcherPriority.SystemIdle,
                        new Action(() =>
                        {
                            try
                            {
                                UsbMonitor.NewInstance().Encrypt(password, (index) =>
                                {
                                    SetLabelMsg($"正在加密: {index}");
                                });
                                LoginSuccessCallback();
                                Close();
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                                MessageBox.Show("加密失败");
                            }
                            finally
                            {
                                Close();
                            }
                        }));
                    break;
                case UsbConst.VALID_FILE_DESTORY:       // 文件已销毁
                    MessageBox.Show("用户名密码错误, 文件已销毁");
                    this.Close();
                    break;
                default:                                // 验证失败
                    SetLabelMsg($"用户名密码不正确！您还有{valid}次机会");
                    break;
            }
        }

        /// <summary>
        /// 取消输入密码
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();   // 关闭对话框
        }
    }
}
