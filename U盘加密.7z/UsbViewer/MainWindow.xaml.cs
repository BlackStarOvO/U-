﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using USBMonitor;

namespace UsbViewer
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        private UsbMonitor usbMonitor;
        private bool bUsbEncrypt;
        private List<object> lst;           // 文件列表
        private string parent;              // 父目录

        public MainWindow()
        {
            InitializeComponent();
            SourceInitialized += new EventHandler(MainWindow_SourceInitialized);
            WindowState = WindowState.Minimized;
        }

        /// <summary>
        /// 重写closing方法, 阻止关闭程序
        /// </summary>
        /// <param name="e"></param>
        protected override void OnClosing(CancelEventArgs e)
        {
            //e.Cancel = true;                        // 阻止关闭
            //this.WindowState = WindowState.Minimized;
            base.OnClosing(e);
        }

        private void MainWindow_SourceInitialized(object sender, EventArgs e)
        {
            IntPtr hwnd = new WindowInteropHelper(this).Handle;
            HwndSource.FromHwnd(hwnd).AddHook(new HwndSourceHook(WndProc));
            usbMonitor = UsbMonitor.NewInstance();
            usbMonitor.IsUsbEncryptCallback = IsUsbEncrypt;
            
        }

        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            usbMonitor.CheckMsg(msg, wParam);
            return IntPtr.Zero;
        }

        /// <summary>
        /// usb是否加密
        /// </summary>
        /// <param name="usb_state"></param>
        private void IsUsbEncrypt(int usb_state)
        {
            // 显示窗口
            this.Visibility = Visibility.Visible;

            bUsbEncrypt = usb_state == UsbConst.USB_STATE_ENCRYPT;
            // 弹出对话框, 选择是否加密
            if (!bUsbEncrypt)       // 未加密弹出对话框询问是否加密
            {
                var result = MessageBox.Show("U盘未加密, 是否加密?", "是否加密", 
                    MessageBoxButton.OKCancel,
                    MessageBoxImage.Question, MessageBoxResult.OK);
                if (result == MessageBoxResult.Cancel)
                {
                    return;
                }
            }
            // 弹出输入用户名和密码的对话框
            var sv = ShowView.NewInstance();
            sv.LoginCallback = LoginSuccess;
            sv.LoginWindow.Owner = this;
            sv.ShowLoginWindow("请输入用户名和密码");
        }

        /// <summary>
        /// 登陆成功, 加载U盘文档
        /// </summary>
        private void LoginSuccess()
        {
            SetList("");
            foreach (var win in  Application.Current.Windows)
            {
                (win as Window).WindowState = WindowState.Normal;
            }
        }

        /// <summary>
        /// 设置列表
        /// </summary>
        /// <param name="path"></param>
        private void SetList(string path)
        {
            list_show.Items.Clear();

            if (".aes".Equals(Path.GetExtension(path)))     // 不需要文件
            {
                return;
            }

            lst = usbMonitor.GetItems(path);                // 获取内容
            if (lst == null)
            {
                return;
            }

            foreach (var p in lst)
            {
                if (p is DirectoryInfo)
                {
                    list_show.Items.Add((p as DirectoryInfo).Name);
                }
                else
                {
                    list_show.Items.Add((p as FileInfo).Name.Replace(".aes", ""));
                }
            }

            if (!(string.IsNullOrEmpty(path) || string.IsNullOrWhiteSpace(path)))
            {
                list_show.Items[0] = ". . .";
                parent = path;
            }
            else
            {
                parent = usbMonitor.usb_root.FullName;
            }
            text_info.Text = parent;
        }

        /// <summary>
        /// 获取列表中被选中项
        /// </summary>
        /// <returns></returns>
        private object GetSelectedFromList()
        {
            var item = text_info.Text;
            Console.WriteLine(item);
            if (item.Contains(". . ."))
            {
                return null;
            }
            foreach (var data in lst)                           // 循环查找名称
            {
                if (data is FileInfo)
                {
                    var f = data as FileInfo;
                    if (f.FullName.Replace(".aes", "").Equals(item))
                    {
                        return f;
                    }
                }
                else
                {
                    var d = data as DirectoryInfo;
                    if (d.FullName.Equals(item))
                    {
                        return d;
                    }
                }
            }
            
            return null;
        }

        /// <summary>
        /// 双击打开
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void list_show_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var text = (sender as ListBox).SelectedItem.ToString();
            if (text.Trim().Equals(". . ."))
            {
                SetList("");
                return;
            }

            foreach (var obj in lst)
            {
                if (obj is DirectoryInfo)
                {
                    var item = obj as DirectoryInfo;
                    if (item.Name.Equals(text))
                    {
                        SetList(item.FullName);
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// 选择
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void list_show_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var text = (sender as ListBox).SelectedItem?.ToString();
            if (text == null)
            {
                return;
            }
            text_info.Text = Path.Combine(parent, text);            
        }

        /// <summary>
        /// 解密选中的文档
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void decrypt_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var f = GetSelectedFromList();
                if (f == null || f is DirectoryInfo)
                {
                    return;
                }
                var data = f as FileInfo;
                // 获取保存文件夹
                var dir = ShowView.NewInstance().OpenDirectory(this);
                if (dir == null)
                {
                    return;
                }
                string newFile = Path.Combine(dir, data.Name);
                usbMonitor.Decrypt(data.CopyTo(newFile));
                ShowView.NewInstance().OpenDirectory(newFile);
                MessageBox.Show("解密成功");
            }
            catch
            {
                MessageBox.Show("解密失败");
                SetList("");
            }
        }

        /// <summary>
        /// 删除选中的文档
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {                
                var f = GetSelectedFromList();
                if (f == null)
                {
                    return;
                }
                if (f is FileInfo)
                {
                    (f as FileInfo).Delete();
                }
                else
                {
                    var d = f as DirectoryInfo;                    
                    usbMonitor.Destory(f as DirectoryInfo);
                }
                SetList(parent);
            }
            catch
            {
                SetList("");
            }
        }

        /// <summary>
        /// 添加文档到U盘中
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void insert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // 获取要加密的文件
                var fname = ShowView.NewInstance().OpenSelectFile();
                if (string.IsNullOrEmpty(fname) || string.IsNullOrWhiteSpace(fname))
                {
                    return;
                }
                var f = new FileInfo(fname);
                string newFile = Path.Combine(parent, f.Name);
                usbMonitor.Encrypt(f, newFile);
                SetList(parent);
            }
            catch
            {
                SetList("");
            }
        }
    }
}
