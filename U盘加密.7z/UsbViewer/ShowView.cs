﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;

namespace UsbViewer
{
    public class ShowView
    {
        private static object obj = new object();   // 单例模式
        private static ShowView showView;

        private LoginWindow loginWindow;            // 登录窗口
        public Action LoginCallback;
        public LoginWindow LoginWindow
        {
            get
            {
                if (loginWindow == null)
                {
                    loginWindow = new LoginWindow();                    
                    loginWindow.LoginSuccessCallback = LoginCallback;
                }
                return loginWindow;
            }
        }
        public Action MainWinVisible;

        private ShowView() { }

        public static ShowView NewInstance()
        {
            if (showView == null)
            {
                lock (obj)
                {
                    if (showView == null)
                    {
                        showView = new ShowView();
                    }
                }
            }
            return showView;
        }

        /// <summary>
        /// 显示登陆对话框
        /// </summary>
        public void ShowLoginWindow(string msg)
        {
            if (msg != null)
            {
                LoginWindow.SetLabelMsg(msg);
            }
            LoginWindow.ShowDialog();
        }

        /// <summary>
        /// 打开保存文件夹
        /// </summary>
        /// <returns></returns>
        public string OpenDirectory(Window win)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "请选择解密文件保存的文件夹地址";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                if (string.IsNullOrEmpty(dialog.SelectedPath))
                {
                    System.Windows.MessageBox.Show(win, "文件夹路径不能为空", "提示");
                    return null;
                }
                return dialog.SelectedPath;
            }
            return null;
        }

        /// <summary>
        /// 选择要加密的文件
        /// </summary>
        /// <returns></returns>
        public string OpenSelectFile()
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "*.* | *.*";
            if (open.ShowDialog() == DialogResult.OK)
            {
                return open.FileName;
            }
            return null;
        }

        /// <summary>
        /// 打开指定目录
        /// </summary>
        /// <param name="path"></param>
        public void OpenDirectory(string path)
        {
            System.Diagnostics.Process.Start("explorer.exe", Path.GetDirectoryName(path));            
        }
    }
}
