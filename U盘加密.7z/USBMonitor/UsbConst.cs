﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace USBMonitor
{
    /// <summary>
    /// 常用两
    /// </summary>
    public class UsbConst
    {
        /*
         *  window常量 
         */ 
        public const int WM_DEVICECHANGE = 0x219;               // 系统硬件改变发出的系统消息
        public const int DBT_DEVICEARRIVAL = 0x8000;            // 设备检测结束，并且可以使用
        public const int DBT_CONFIGCHANGECANCELED = 0x0019;
        public const int DBT_CONFIGCHANGED = 0x0018;
        public const int DBT_CUSTOMEVENT = 0x8006;
        public const int DBT_DEVICEQUERYREMOVE = 0x8001;
        public const int DBT_DEVICEQUERYREMOVEFAILED = 0x8002;
        public const int DBT_DEVICEREMOVECOMPLETE = 0x8004;     // 设备卸载或者拔出
        public const int DBT_DEVICEREMOVEPENDING = 0x8003;
        public const int DBT_DEVICETYPEHANGED = 0x0007;
        public const int DBT_QUERYCHANGSPECIFIC = 0x8005;
        public const int DBT_DEVNODES_CECONFIG = 0x0017;
        public const int DBT_USERDEFINED = 0xFFFF;

        /*
         * 自定义常量
         */ 
        public const string CONFIG_PATH = ".aes/config.xml";    // 配置文件路径
        public const string CONFIG_ROOT_NAME = "Users";         // 配置文件节点名称
        public const string CONFIG_ELEM_NAME = "User";          // 配置文件节点名称
        public const string CONFIG_ATTR_USER = "UserName";      // 配置文件节点名称
        public const string CONFIG_ATTR_PASS = "Password";      // 配置文件节点名称
        public const int USB_STATE_UNENCRYPT = 0;               // U盘未加密
        public const int USB_STATE_ENCRYPT = 1;                 // U盘加密

        /*
         * 验证返回消息
         */
        public const int VALID_INIT_COUNT = 3;                  // 初始化验证次数
        public const int VALID_FILE_DESTORY = 0;                // 文件已销毁
        public const int VALID_SUCCESS = 10086;                 // 验证成功
    }
}
