﻿using AES;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using USBMonitor.Xml;

namespace USBMonitor
{
    /// <summary>
    /// USB插拔监控类
    /// </summary>
    public class UsbMonitor
    {
        private static object obj = new object();               // 单例锁对象
        private static UsbMonitor usbMonitor;                   // 单例对象
        private DriveInfo drive;                                // 移动设备(只处理一个)
        public DirectoryInfo usb_root;                          // U盘根目录 
        private string config_root;                             // 配置文件根目录
        private string config_xml;                              // 配置文件目录
        private XDocument doc;                                  // 配置文件文档对象
        private string pass;                                    // 密码

        public Action<int> IsUsbEncryptCallback;                // Usb是否加密     
        public bool bLogin = false;

        private UsbMonitor() 
        {
            // 添加自动启动
            new Tools.QuickStart().SetMeAutoStart();
        }

        /// <summary>
        /// 单例模式
        /// </summary>
        /// <returns></returns>
        public static UsbMonitor NewInstance()
        {
            if (usbMonitor == null)
            {
                lock (obj)
                {
                    if (usbMonitor == null)
                    {
                        usbMonitor = new UsbMonitor();                        
                    }
                }
            }
            return usbMonitor;
        }

        /// <summary>
        /// 检测消息类型
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="wParam"></param>
        public void CheckMsg(int msg, IntPtr wParam)
        {
            if (msg == UsbConst.WM_DEVICECHANGE)
            {
                switch (wParam.ToInt32())
                {
                    case UsbConst.DBT_DEVICEARRIVAL:         //设备插入
                        ScanUsb();
                        UsbArrival();
                        break;
                    case UsbConst.DBT_DEVICEREMOVECOMPLETE:  //设备卸载     
                        break;
                    default:
                        break;
                }
            }
        }

        /// <summary>
        /// 进行登录
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public int Login(string username, string password)
        {
            password = password.CalculateMd5();     // 提取加密文件的摘要信息
            if (IsUsbEncrypt())                     // U盘已经加密就验证用户名和密码
            {
                if (!Validate(username, password))  // 验证不通过
                {
                    int count = ValidateError();    // 验证不通过, 减少一个可用文件
                    if (count == 0)                 // 验证次数已用完, 销毁全部文件
                    {
                        Destory(usb_root);
                    }
                    return count;
                }
            }
            else
            {
                CreateConfigFile(username, password);// 初始化U盘, 创建配置文件
            }
            // 更新验证次数
            UpdateValidFiles();
            pass = password;
            return UsbConst.VALID_SUCCESS;
        }

        /// <summary>
        /// 销毁文件
        /// </summary>
        public bool Destory(DirectoryInfo dirs)
        {
            Stack<DirectoryInfo> stack = new Stack<DirectoryInfo>();
            stack.Push(dirs);
            while (stack.Count > 0)
            {
                var dir = stack.Pop();
                foreach (var f in dir.GetFiles())
                {
                    f.Delete();
                }
                foreach (var d in dir.GetDirectories())
                {
                    stack.Push(d);
                }
            }
            return true;
        }

        /// <summary>
        /// 加密U盘
        /// </summary>
        public void Encrypt(string password, Action<string> Callback)
        {
            password = password.CalculateMd5();
            AESCoding.AesEncrypt(usb_root, password, true, Callback);
        }

        /// <summary>
        /// 加密文件
        /// </summary>
        /// <param name="f"></param>
        public void Encrypt(FileInfo f, string save_path)
        {
            AESCoding.AesEncrypt(f, pass, save_path);
        }

        /// <summary>
        /// 解密文件
        /// </summary>
        /// <param name="password"></param>
        /// <param name="f"></param>
        /// <param name="Callback"></param>
        public void Decrypt(FileInfo f)
        {
            AESCoding.AesDecrypt(f, pass, null);
            f.Delete();
        }

        /// <summary>
        /// 获取文件夹下所有子项
        /// </summary>
        /// <param name="dir_name"></param>
        /// <returns></returns>
        public List<object> GetItems(string dir_name)
        {
            DirectoryInfo obj;
            if (string.IsNullOrEmpty(dir_name) || string.IsNullOrWhiteSpace(dir_name))
            {
                obj = usb_root;
            }
            else
            {
                obj = new DirectoryInfo(dir_name);
            }
            List<object> names = new List<object>();
            if (obj != usb_root)
            {
                names.Add(obj.Parent);
            }
            foreach (var d in obj.GetDirectories())
            {
                if (d.Name.Equals(".aes") || d.Name.Equals("System Volume Information"))
                {
                    continue;
                }
                names.Add(d);
            }
            foreach (var f in obj.GetFiles())
            {
                names.Add(f);
            }
            return names;
        }

        #region PRIVATE METHOD

        /// <summary>
        /// Usb接入
        /// </summary>
        private void UsbArrival()
        {
            bLogin = false;

            usb_root = new DirectoryInfo(drive.RootDirectory.ToString());
            config_root = Path.Combine(usb_root.FullName, ".aes");
            config_xml = Path.Combine(config_root, "config.xml");

            // 判断U盘是否加过密(找是不是有配置文件)
            if (IsUsbEncrypt())
            {
                IsUsbEncryptCallback(UsbConst.USB_STATE_ENCRYPT);                
            }
            else
            {
                IsUsbEncryptCallback(UsbConst.USB_STATE_UNENCRYPT);
            }
        }

        /// <summary>
        /// 判断U盘是否加过密
        /// </summary>
        /// <returns></returns>
        private bool IsUsbEncrypt()
        {
            return File.Exists(config_xml);
        }

        /// <summary>
        /// 验证用户名密码是否存在
        /// </summary>
        /// <returns>是否验证成功</returns>
        private bool Validate(string username, string password)
        {
            if (doc == null)
            {
                doc = XmlHelper.ReadXmlDoc(config_xml);
            }
            var query = from elem in doc.Root.Elements(UsbConst.CONFIG_ELEM_NAME)
                        where username.Equals(elem.Attribute(UsbConst.CONFIG_ATTR_USER).Value)
                        select elem.Attribute(UsbConst.CONFIG_ATTR_PASS).Value;
            foreach (var p in query)
            {
                if (password.Equals(p))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 验证不过
        /// </summary>
        /// <returns></returns>
        private int ValidateError()
        {
            // 获取次数文件
            DirectoryInfo dir = new DirectoryInfo(Path.Combine(config_root, "valid"));
            var files = dir.GetFiles();
            if (files == null || files.Length == 0)
            {
                return UsbConst.VALID_FILE_DESTORY;
            }
            else 
            {
                files[0].Delete();
                return files.Length;
            }
        }

        /// <summary>
        /// 创建配置文件
        /// </summary>
        private void CreateConfigFile(string username, string password)
        {
            // 创建根文件夹
            Directory.CreateDirectory(config_root);
            // 创建配置文件
            XDocument doc = new XDocument();
            XElement root = new XElement(
                UsbConst.CONFIG_ROOT_NAME,
                new XElement(
                    UsbConst.CONFIG_ELEM_NAME,
                    new XAttribute[] {
                        new XAttribute(UsbConst.CONFIG_ATTR_USER, username),
                        new XAttribute(UsbConst.CONFIG_ATTR_PASS, password)
                    }));
            doc.Add(root);
            doc.Save(config_xml);
        }

        /// <summary>
        /// 更新验证文件
        /// </summary>
        private void UpdateValidFiles()
        {
            // 创建验证文件夹
            string valid_root = Path.Combine(config_root, "valid");
            DirectoryInfo dir = null;
            if (!Directory.Exists(valid_root))
            {
                dir = Directory.CreateDirectory(valid_root);
            }
            if (dir == null)
            {
                dir = new DirectoryInfo(valid_root);
            }
            // 删除所有文件
            foreach (var f in dir.GetFiles())
            {
                f.Delete();
            }
            // 重新添加文件
            for (int i = 0; i < UsbConst.VALID_INIT_COUNT; i++)
            {
                File.Create(Path.Combine(valid_root, DateTime.Now.Millisecond.ToString() + ".txt")).Close();
            }

        }

        /// <summary>
        /// 扫描U口设备
        /// </summary>
        private void ScanUsb()
        {
            DriveInfo[] drives = DriveInfo.GetDrives();

            foreach (DriveInfo drive in drives)
            {
                if ((drive.DriveType == DriveType.Removable) && !drive.Name.Substring(0, 1).Equals("A"))
                {
                    try
                    {
                        this.drive = drive;
                        break;
                    }
                    catch
                    {
                        MessageBox.Show("当前盘不能正确识别，请重新尝试！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        #endregion
    }
}
