﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace USBMonitor.Xml
{
    public class ElemAttribute
    {
        public ElemAttribute(bool bFile)
        {
            IsFile = bFile;
            FileInfo file = new FileInfo("");            
        }

        public bool IsFile { get; }
        public long CreationTime { get; set; }
    }
}
