﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace USBMonitor.Xml
{
    public static class XmlHelper
    {
        private const string STR_FILE           = "File";       // 文件类型
        private const string STR_DIRECTORY      = "Directory";  // 文件夹类型
        
        /// <summary>
        /// 读取Xml文档
        /// </summary>
        /// <param name="f"></param>
        /// <returns></returns>
        public static XDocument ReadXmlDoc(this string f)
        {
            return XDocument.Load(f);
        }
    }
}
