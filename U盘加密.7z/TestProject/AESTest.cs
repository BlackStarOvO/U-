﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Threading;
using AES;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestProject
{
    [TestClass]
    public class AESTest
    {
        private string Key { get { return "XinagHuai".CalculateMd5(); } }

        [TestMethod]
        public void TestEncryptFile()
        {
            //AESCoding.AesEncrypt(new DirectoryInfo(@"E:\文献"),
            //    Key, "", false);


        }
    }
}
