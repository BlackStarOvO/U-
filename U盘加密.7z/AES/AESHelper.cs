﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AES
{
    public static class AESHelper
    {
        public static byte[] GetBytes(this int source) => BitConverter.GetBytes(source);
        public static byte[] GetBytes(this string source) => Encoding.UTF8.GetBytes(source);
        public static int GetInteger(this byte[] bytes) => BitConverter.ToInt32(bytes, 0);
        public static string GetString(this byte[] bytes, int start, int count) => Encoding.UTF8.GetString(bytes, start, count);
    }
}
