﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace AES
{
    public static class MD5Coding
    {
        /// <summary>
        /// 获取字节数组的md5值
        /// </summary>
        /// <param name="bytes">需要计算的字节数组</param>
        /// <returns>字节数组的md5值</returns>
        public static String CalculateMd5(this byte[] bytes)
        {
            StringBuilder builder = new StringBuilder(32);
            using (MD5 md5 = MD5.Create())
            {
                bytes = md5.ComputeHash(bytes);
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("X").PadLeft(2, '0'));
                }
            }
            return builder.ToString();
        }

        /// <summary>
        /// 获取字符串的md5值
        /// </summary>
        /// <param name="source">需要进行md5计算的字符串</param>
        /// <returns>字符串的md5值</returns>
        public static String CalculateMd5(this String source)
        {
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(source);
            return CalculateMd5(bytes);
        }

    }
}
