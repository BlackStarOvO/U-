﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace AES
{
    public static class AESCoding
    {
        private static Random random = new Random();        

        private const int EOF               = 0;        // 流结束标志
        private const int ENCRYPT           = 1;        // 加密标志
        private const int UN_ENCRYPT        = 2;        // 未加密标志
        private const int FILE_EXT          = 3;        // 文件后缀名
        private const int FILE_AES          = 0xABCCBA; // 是否是AES加密文件

        /// <summary>
        /// 对字符串进行加密
        /// </summary>
        /// <param name="str">要加密的字符串</param>
        /// <param name="key">加密密码</param>
        /// <returns>加密后的字符串</returns>
        public static string AesEncrypt(string str, string key)
        {
            if (string.IsNullOrEmpty(str)) return null;
            byte[] toEncryptArray = Encoding.UTF8.GetBytes(str);

            byte[] resultArray = AesEncrypt(toEncryptArray, key);

            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }

        /// <summary>
        /// 对加密的字符串进行解密
        /// </summary>
        /// <param name="str">加密的字符串</param>
        /// <param name="key">密码</param>
        /// <returns>解密的字符串</returns>
        public static string AesDecrypt(string str, string key)
        {
            if (string.IsNullOrEmpty(str)) return null;
            byte[] toEncryptArray = Convert.FromBase64String(str);

            byte[] resultArray = AesDecrypt(toEncryptArray, key);

            return Encoding.UTF8.GetString(resultArray);
        }

        /// <summary>
        /// 对字节数组进行加密
        /// </summary>
        /// <param name="original">原字节数组</param>
        /// <param name="key">加密密码</param>
        /// <returns>加密后的字节数组</returns>
        public static byte[] AesEncrypt(byte[] original, string key)
        {
            RijndaelManaged rm = new RijndaelManaged
            {
                Key = Encoding.UTF8.GetBytes(key),
                Mode = CipherMode.ECB,
                Padding = PaddingMode.PKCS7
            };

            ICryptoTransform cTransform = rm.CreateEncryptor();
            return cTransform.TransformFinalBlock(original, 0, original.Length);
        }

        /// <summary>
        /// 对加密的字节数组进行解密
        /// </summary>
        /// <param name="original">加密的字节数组</param>
        /// <param name="key">加密密码</param>
        /// <returns>解密后的字节数组</returns>
        public static byte[] AesDecrypt(byte[] original, string key)
        {
            RijndaelManaged rm = new RijndaelManaged
            {
                Key = Encoding.UTF8.GetBytes(key),
                Mode = CipherMode.ECB,
                Padding = PaddingMode.PKCS7
            };

            ICryptoTransform cTransform = rm.CreateDecryptor();
            return cTransform.TransformFinalBlock(original, 0, original.Length);
        }

        /// <summary>
        /// 对文件进行加密
        /// </summary>
        /// <param name="f">源文档对象</param>
        /// <param name="key">加密密码</param>
        /// <param name="dest_path">解密文件保存路径</param>
        public static void AesEncrypt(FileInfo f, string key, string dest_path)
        {
            using (var sour_stream = f.OpenRead())
            using (var dest_stream = File.Create("temporary"))         // 使用临时文件
            {
                byte[] bytes = new byte[1024];

                byte[] data = null;

                dest_stream.Write(FILE_AES.GetBytes(), 0, 4);           // AES加密文件标志

                dest_stream.WriteByte(FILE_EXT);                        // 文件后缀
                data = f.Extension.GetBytes();
                dest_stream.Write(data.Length.GetBytes(), 0, 4);
                dest_stream.Write(data, 0, data.Length);

                while (sour_stream.Read(bytes, 0, 1024) > 0)
                {
                    if (RandomBool())                                   // 是否加密 
                    {
                        data = AesEncrypt(bytes, key);
                        dest_stream.WriteByte(ENCRYPT);                 // 加密标志    
                    }
                    else
                    {
                        data = bytes;
                        dest_stream.WriteByte(UN_ENCRYPT);
                    }
                    dest_stream.Write(data.Length.GetBytes(), 0, 4);    // 数据长度
                    dest_stream.Write(data, 0, data.Length);            // 数据内容
                }
                dest_stream.WriteByte(EOF);                             // 结束标志
                // 判断是否使用默认路径
                if (dest_path == null)
                {
                    dest_path = f.FullName;
                    dest_path = dest_path + ".aes";
                }
                if (!dest_path.EndsWith(".aes"))
                {
                    dest_path += ".aes";
                }
            }
            if (File.Exists(dest_path)) File.Delete(dest_path);
            // 移动临时文件
            File.Move("temporary", dest_path);
        }

        /// <summary>
        /// 对加密文件进行解密
        /// </summary>
        /// <param name="f">加密文件</param>
        /// <param name="key">解密密码</param>
        /// <param name="dest_path">解密文件保存路径</param>
        public static void AesDecrypt(FileInfo f, string key, string dest_path)
        {
            using (var sour_stream = f.OpenRead())                      // 加密文件
            using (var dest_stream = File.Create("temporary"))          // 解密文件(临时文件)
            {
                byte[] bytes = new byte[1040];

                sour_stream.Read(bytes, 0, 4);                          // 读取AES加密标志
                if (bytes.GetInteger() != FILE_AES)                     // 文件不是AES加密文件
                {
                    throw new Exception("该文件不是AES加密文件");
                }

                bool flag = true;
                int length = 0;
                string file_ext = "";                                   // 文件后缀
                while (flag)
                {
                    switch (sour_stream.ReadByte())
                    {
                        case ENCRYPT:                                   // 加密
                            sour_stream.Read(bytes, 0, 4);              // 数据长度
                            length = bytes.GetInteger();
                            sour_stream.Read(bytes, 0, length);         // 读取数据
                            var data = AesDecrypt(bytes, key);          // 解密
                            dest_stream.Write(data, 0, data.Length);    // 写入
                            break;
                        case UN_ENCRYPT:                                // 未加密
                            sour_stream.Read(bytes, 0, 4);              // 数据长度
                            length = bytes.GetInteger();
                            length = sour_stream.Read(bytes, 0, length);// 读取数据
                            dest_stream.Write(bytes, 0, length);        // 写入
                            break;
                        case FILE_EXT:                                  // 文件后缀名
                            sour_stream.Read(bytes, 0, 4);
                            length = bytes.GetInteger();
                            sour_stream.Read(bytes, 0, length);
                            file_ext = bytes.GetString(0, length);
                            break;
                        case EOF:                                       // 结束
                            flag = false;
                            break;
                        default:
                            throw new Exception("数据解析错误");
                    }
                }
                dest_stream.Flush();
                // 是否使用默认的dest地址
                if (dest_path == null)
                {
                    dest_path = f.FullName;
                    dest_path = dest_path.Substring(0, dest_path.IndexOf(".")) + file_ext;                    
                }
            }
            if (File.Exists(dest_path)) File.Delete(dest_path);
            File.Move("temporary", dest_path);
        }
        
        /// <summary>
        /// 将文件夹下的文件进行加密
        /// </summary>
        /// <param name="d">需要加密的文件夹</param>
        /// <param name="key">加密密码</param>
        /// <param name="bDeleteOriginal">是否删除源文件</param>
        public static void AesEncrypt(DirectoryInfo d, string key, bool bDeleteOriginal, Action<string> Callback)
        {
            Stack<DirectoryInfo> stack = new Stack<DirectoryInfo>();// 使用栈进行遍历
            stack.Push(d);
            // 开始遍历
            while (stack.Count > 0)
            {
                var dir = stack.Pop();  
                foreach (var f in dir.GetFiles())                   // 遍历文件夹下的文件, 进行加密
                {
                    if (f.Extension.Equals(".aes"))
                    {
                        continue;
                    }
                    Callback(f.FullName);                           // 对外提供进行度
                    AesEncrypt(f, key, null);                       // 文件加密, 保存到源文档同级目录下
                    if (bDeleteOriginal)                            // 是否删除源文件
                    {
                        f.Delete();
                    }
                }
                foreach (var _d in dir.GetDirectories())            // 文件夹下的所有文件夹都要入栈
                {
                    if (_d.Name.Equals(".aes") || _d.Name.Equals("System Volume Information"))
                    {
                        continue;
                    }
                    stack.Push(_d);
                }
            }
        }

        /// <summary>
        /// 解密文件夹下的加密文件
        /// </summary>
        /// <param name="d">需要解密的文件夹</param>
        /// <param name="key">解密密码</param>
        /// <param name="bDeleteOriginal">是否删除加密文件</param>
        public static void AesDecrypt(DirectoryInfo d, string key, bool bDeleteOriginal, Action<string> Callback)
        {
            Stack<DirectoryInfo> stack = new Stack<DirectoryInfo>();// 使用栈进行遍历
            stack.Push(d);
            // 开始遍历
            while (stack.Count > 0)
            {
                var dir = stack.Pop();                              // 出栈
                foreach (var f in dir.GetFiles())                   // 遍历文件夹下的文件, 进行加密
                {
                    if (f.Extension.Equals(".aes"))
                    {
                        AesDecrypt(f, key, null);                   // 文件加密, 保存到源文档同级目录下
                        if (bDeleteOriginal)                        // 是否删除源文件
                        {
                            f.Delete();
                        }
                        Callback(f.FullName);                              // 对外提供解密进度
                    }
                }
                foreach (var _d in dir.GetDirectories())            // 文件夹下的所有文件夹都要入栈
                {
                    stack.Push(_d);
                }
            }
        }
       
        #region PRIVATE METHOD

        /// <summary>
        /// 随机生成bool变量
        /// </summary>
        /// <returns></returns>
        private static bool RandomBool()
        {
            return random.Next() % 2 == 0;
        }

        #endregion
    }
}
